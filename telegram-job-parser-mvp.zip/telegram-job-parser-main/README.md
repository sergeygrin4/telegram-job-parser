# 🤖 Telegram Job Parser MVP

Рабочее мини-приложение для Telegram для сбора и управления вакансиями из Telegram-каналов.

## ✨ Возможности MVP

- 📋 **Просмотр вакансий** - все собранные вакансии в удобном интерфейсе
- 📢 **Управление каналами** - добавление и удаление каналов для мониторинга
- 🔔 **Уведомления** - новые вакансии приходят менеджеру в Telegram
- 💾 **База данных** - все вакансии сохраняются в SQLite
- 🌐 **Mini App** - встроенный интерфейс в Telegram

## 🚀 Быстрый деплой на Railway

### Шаг 1: Создание Telegram бота

1. Откройте [@BotFather](https://t.me/BotFather) в Telegram
2. Отправьте команду `/newbot`
3. Придумайте имя и username для бота
4. **Сохраните токен** (например: `7952407611:AAF_J8xFIE4FEL5Kmf6cFMUL0BZaEQsn_7s`)

### Шаг 2: Получение Chat ID

1. Откройте [@userinfobot](https://t.me/userinfobot) в Telegram
2. Нажмите `/start`
3. **Сохраните ваш ID** (например: `794618749`)

### Шаг 3: Деплой на Railway

1. Зайдите на [Railway.app](https://railway.app) и войдите через GitHub
2. Нажмите **"New Project"** → **"Deploy from GitHub repo"**
3. Выберите репозиторий `telegram-job-parser`
4. Railway автоматически обнаружит `Dockerfile` и начнет деплой

### Шаг 4: Настройка переменных окружения

В Railway Dashboard → ваш проект → **Variables**, добавьте:

```env
BOT_TOKEN=7952407611:AAF_J8xFIE4FEL5Kmf6cFMUL0BZaEQsn_7s
MANAGER_CHAT_ID=794618749
SHARED_SECRET=my-super-secret-key-123
WEB_APP_URL=https://your-app.up.railway.app
DB_PATH=/data/jobs.db
```

**⚠️ Важно:**
- `BOT_TOKEN` - замените на свой токен от BotFather
- `MANAGER_CHAT_ID` - замените на свой Chat ID
- `SHARED_SECRET` - придумайте любую случайную строку
- `WEB_APP_URL` - скопируйте URL после первого деплоя (см. следующий шаг)

### Шаг 5: Получение URL приложения

1. После первого деплоя Railway присвоит вашему приложению URL
2. Найдите его в **Settings** → **Domains** → **Generate Domain**
3. Скопируйте URL (например: `https://telegram-job-parser-production.up.railway.app`)
4. Обновите переменную `WEB_APP_URL` этим URL
5. Перезапустите приложение

### Шаг 6: Настройка Menu Button

Вернитесь к [@BotFather](https://t.me/BotFather) и настройте кнопку:

```
/setmenubutton
Выберите вашего бота
Введите текст кнопки: 🔍 Открыть поиск
Введите URL: https://your-app.up.railway.app/index.html
```

**Замените `your-app.up.railway.app` на ваш реальный URL!**

### Шаг 7: Настройка хранилища (опционально, но рекомендуется)

Для сохранения БД между перезапусками:

1. В Railway Dashboard → ваш проект → **Volumes**
2. Нажмите **New Volume**
3. Укажите **Mount Path**: `/data`
4. Сохраните

## 📱 Использование

1. Откройте вашего бота в Telegram
2. Нажмите `/start`
3. Нажмите кнопку **"🔍 Открыть поиск"** в меню
4. В мини-апе:
   - **Вкладка "Вакансии"** - просмотр всех собранных вакансий
   - **Вкладка "Каналы"** - добавление/удаление каналов для мониторинга

## 🔧 Опциональный парсер (для автоматического сбора)

Если хотите автоматически собирать вакансии из каналов:

### 1. Получите API креды Telegram

1. Откройте https://my.telegram.org/
2. Войдите через телефон
3. Перейдите в **API Development Tools**
4. Создайте приложение и сохраните:
   - **API ID** (например: `28658232`)
   - **API Hash** (например: `faa917cd40fc853f884f25f43dd0b123`)

### 2. Добавьте переменные в Railway

```env
TELEGRAM_API_ID=28658232
TELEGRAM_API_HASH=faa917cd40fc853f884f25f43dd0b123
TELETHON_SESSION=/data/parser.session
CHANNELS=@python_jobs,@js_jobs
BOT_API=https://your-app.up.railway.app/post
```

### 3. Создайте второй сервис в Railway

1. В том же проекте нажмите **New Service**
2. Выберите тот же репозиторий
3. В **Settings** → **Start Command** укажите: `python telegram_parser.py`
4. Добавьте те же переменные окружения

### 4. Первый запуск парсера

При первом запуске Telethon попросит авторизацию:
- Проверьте логи Railway
- Вам придет код в Telegram
- Введите код в консоль (нужен доступ к Railway CLI или проще запустить локально первый раз)

## 📁 Структура проекта

```
telegram-job-parser/
├── mini_app_bot.py          # Основной сервер (Flask + Telegram Bot)
├── telegram_parser.py       # Парсер каналов (опционально)
├── static/
│   └── index.html          # Frontend мини-приложения
├── requirements.txt        # Python зависимости
├── Dockerfile             # Конфигурация для Railway
├── Procfile              # Альтернативная конфигурация
└── .env.sample          # Пример переменных окружения
```

## 🔍 API Endpoints

### POST /post
Прием вакансий от парсера

**Headers:**
- `X-SECRET`: Секретный ключ из SHARED_SECRET
- `Content-Type`: application/json

**Body:**
```json
{
  "chat_title": "Python Jobs",
  "text": "Senior Python Developer, Remote, $150k",
  "link": "https://t.me/python_jobs/12345"
}
```

### GET /api/jobs
Получение списка вакансий

**Query params:**
- `limit` (default: 50)
- `offset` (default: 0)

### GET /api/channels
Получение списка каналов

### POST /api/channels
Добавление канала

**Body:**
```json
{
  "username": "python_jobs"
}
```

### DELETE /api/channels/:id
Удаление канала

## 💻 Локальная разработка

```bash
# Клонирование
git clone https://github.com/sergeygrin4/telegram-job-parser.git
cd telegram-job-parser

# Создание виртуального окружения
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Установка зависимостей
pip install -r requirements.txt

# Настройка переменных
cp .env.sample .env
# Отредактируйте .env файл

# Запуск
python mini_app_bot.py
```

## 🐛 Устранение проблем

### Мини-ап не открывается
- ✅ Проверьте, что `WEB_APP_URL` установлен правильно в Railway
- ✅ Убедитесь, что URL в Menu Button совпадает с `WEB_APP_URL/index.html`
- ✅ Проверьте статус приложения в Railway (должен быть Active)
- ✅ Попробуйте открыть `https://your-app.up.railway.app/health` - должен вернуть `{"status": "ok"}`

### Бот не отвечает на /start
- ✅ Проверьте `BOT_TOKEN` в переменных окружения
- ✅ Посмотрите логи в Railway Dashboard
- ✅ Напишите боту `/start` чтобы инициализировать диалог

### Вакансии не сохраняются
- ✅ Создайте Volume в Railway с путем `/data`
- ✅ Проверьте, что `DB_PATH=/data/jobs.db`

### Парсер не запускается
- ✅ Убедитесь, что `TELEGRAM_API_ID` и `TELEGRAM_API_HASH` установлены
- ✅ При первом запуске нужна авторизация (проверьте логи)
- ✅ Убедитесь, что `BOT_API` указывает на правильный URL

## 🎯 Что работает в MVP

✅ Telegram бот с Mini App  
✅ Просмотр вакансий через веб-интерфейс  
✅ Добавление/удаление каналов для мониторинга  
✅ Сохранение вакансий в БД  
✅ Уведомления менеджеру о новых вакансиях  
✅ REST API для интеграций  
✅ Деплой на Railway

## 📝 TODO для будущих улучшений

- [ ] Фильтры и поиск по вакансиям
- [ ] Парсинг Facebook (нужны креды FB)
- [ ] Экспорт вакансий в CSV/Excel
- [ ] Статистика по каналам
- [ ] Webhook вместо polling для бота
- [ ] PostgreSQL вместо SQLite для production

## 📞 Поддержка

Если возникли проблемы:
1. Проверьте логи в Railway Dashboard
2. Убедитесь, что все переменные окружения установлены
3. Проверьте, что приложение запущено (статус Active)
4. Откройте issues на GitHub

## 📝 Лицензия

MIT
